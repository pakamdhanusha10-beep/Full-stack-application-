CREATE DATABASE IF NOT EXISTS studentdb;
USE studentdb;

CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    course VARCHAR(100) NOT NULL
);

INSERT INTO students (name, email, course)
SELECT 'Dhanusha', 'dhanusha@example.com', 'CSE'
WHERE NOT EXISTS (
    SELECT 1 FROM students WHERE email = 'dhanusha@example.com'
);

INSERT INTO students (name, email, course)
SELECT 'Ravi', 'ravi@example.com', 'CSE'
WHERE NOT EXISTS (
    SELECT 1 FROM students WHERE email = 'ravi@example.com'
);
